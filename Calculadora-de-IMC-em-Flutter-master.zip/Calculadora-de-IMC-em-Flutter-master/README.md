# Calculadora de IMC em Flutter
Aplicativo híbrido para cálculo do IMC

Esse aplicativo foi escrito em Dart usando o Flutter (SDK mobile do Google) como parte de um curso.
Todos os componentes foram construídos por meio de Widgets sem a necessidade de usar componentes nativos do iOS ou Android.

## iOS e Android
![ios_e_android](https://user-images.githubusercontent.com/7269894/68603791-c88cfb00-0487-11ea-9b38-aa2e722dc988.png)

## Demonstração
![](https://user-images.githubusercontent.com/7269894/68592357-a25c6080-0471-11ea-8c4f-a44fece03010.gif)
